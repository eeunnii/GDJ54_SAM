package com.gdu.app15.service;

public interface BlogService {

}
